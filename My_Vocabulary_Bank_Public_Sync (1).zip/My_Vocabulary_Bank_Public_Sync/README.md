# My Vocabulary Bank — Public Shared Cloud Edition

**Independent new website.** Do not deploy over your existing `charming-pudding-fec6f8` Netlify site.

## Architecture
- Netlify hosts `index.html` and `netlify/functions/api.js`.
- Netlify Function accesses Supabase REST API with server-only `SUPABASE_SERVICE_ROLE_KEY`.
- Supabase `mvb_public_words` and `mvb_public_attempts` tables store shared vocabulary and quiz history.
- Browser NEVER receives the service role key. No browser localStorage used for vocabulary.
- RLS enabled and anon/authenticated grants revoked. The server-side service role bypasses RLS.
- All visitors with the site URL can modify shared data. This is NOT private or resistant to malicious edits. A rate limit/WAF and regular backups are recommended before public exposure.

## Setup (in order)
1. Supabase dashboard -> select existing project `disvzidgchfujybpkobb` -> SQL Editor -> New query -> paste `schema.sql` -> Run. It creates new namespaced tables only; does not remove old tables.
2. Netlify -> Add new project -> Deploy manually. **Important:** Netlify Drop/manual drag-and-drop may not build or deploy Functions from source. To ensure Functions are built, use Netlify CLI from a computer, or connect a Git repository. For Netlify CLI: `npm install -g netlify-cli`, `netlify login`, in this directory `netlify init` (create NEW site), then `netlify deploy --build --prod`. Netlify site must be NEW, not old.
3. New Netlify site -> Site configuration -> Environment variables -> Add variable:
   - `SUPABASE_URL` = `https://disvzidgchfujybpkobb.supabase.co`
   - `SUPABASE_SERVICE_ROLE_KEY` = Supabase dashboard -> Project Settings -> API Keys -> service_role/secret key. **NEVER send this key in chat, never add it to HTML or source code.** Set only in Netlify environment variable, and do not expose as `VITE_`.
   - Netlify CLI build/deploy after setting environment variables. A redeploy may be required.
4. Test new Netlify URL: dashboard should say connected. Add a test word on desktop, refresh iPhone on same new URL, confirm it appears; edit and delete across devices. Test failure by disconnecting network: should display error.
5. Go to Import & Backup to import included TOEIC CSV. The CSV contains 100 TOEIC-style words with English definitions and examples. Duplicate words are skipped.

## Critical limitations
- No login or access code means **no ownership or user isolation**. Anybody with the URL can add/edit/delete words, and can see quiz attempts.
- Netlify Functions are public API endpoints. Hiding Supabase key is not equivalent to securing edits. API input validation and Netlify controls help, but cannot distinguish legitimate owner from malicious visitor.
- No real-time push: refresh every 15 seconds while page is open, on tab focus, or manual refresh.
- No guaranteed offline write queue. Network errors are shown and users should retry.
- Quiz English-definition MCQ requires at least four words with English definitions.
- `schema.sql` uses `create table if not exists` and a trigger only for newly namespaced table; check existing objects before running if you have already installed this new edition.

## Files
- `index.html`: responsive app.
- `netlify/functions/api.js`: cloud CRUD and quiz history API.
- `netlify.toml`: Netlify build config.
- `schema.sql`: new tables, RLS, permissions.
- `TOEIC_100_Common_Vocabulary.csv`: import-ready starter words.
