-- New namespaced tables. Does not touch existing tables.
create extension if not exists pgcrypto;
create table if not exists public.mvb_public_words (
 id uuid primary key default gen_random_uuid(),
 word text not null,
 meaning_zh text not null,
 definition_en text not null default '',
 example_en text not null default '',
 example_zh text not null default '',
 part_of_speech text not null default '',
 category text not null default '',
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now(),
 constraint mvb_public_word_len check (char_length(word) between 1 and 120),
 constraint mvb_public_meaning_len check (char_length(meaning_zh) between 1 and 500)
);
create unique index if not exists mvb_public_words_word_lower_uq on public.mvb_public_words (lower(btrim(word)));
create or replace function public.mvb_public_touch_updated_at() returns trigger language plpgsql as $$ begin new.updated_at=now(); return new; end; $$;
drop trigger if exists mvb_public_words_updated on public.mvb_public_words;
create trigger mvb_public_words_updated before update on public.mvb_public_words for each row execute function public.mvb_public_touch_updated_at();
create table if not exists public.mvb_public_attempts (
 id uuid primary key default gen_random_uuid(),
 word_id uuid not null references public.mvb_public_words(id) on delete cascade,
 correct boolean not null,
 answer text not null default '',
 question text not null default '',
 created_at timestamptz not null default now()
);
create index if not exists mvb_public_attempts_created_idx on public.mvb_public_attempts (created_at desc);
alter table public.mvb_public_words enable row level security;
alter table public.mvb_public_attempts enable row level security;
-- No anon/authenticated policies. The service role (only in Netlify server environment) bypasses RLS.
revoke all on public.mvb_public_words from anon, authenticated;
revoke all on public.mvb_public_attempts from anon, authenticated;
-- Public visitors can use the Netlify API. This is NOT a private app.
